The Password Manager allows users to change or reset their password.
