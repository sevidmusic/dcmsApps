A place experiment with PDO related things. Currently supports MySql.
