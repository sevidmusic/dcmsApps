<?php
echo '<h3>Delete</h3>';
var_dump($userCrud->delete(PDO_PLAY_DEV_USER_NAME1,PDO_PLAY_DEV_USER_PASS1));
