<?php
/**
 * Create a new Data Base the PDO way.
 * Source for boilerplate @see https://stackoverflow.com/questions/2583707/can-i-create-a-database-using-pdo-in-php
 * WARNING: THE FOLLOWING CODE IS FOR LOCAL DEV ONLY! DO NOT USE IN ANY PRODUCTION SITE!!!
 */
