<?php

class devUser
{
    private $userName;
    private $userId;
    private $userMeta;

    public function getUserName()
    {
        return $this->userName;
    }

    public function getUserId()
    {
        return $this->userId;
    }

}
