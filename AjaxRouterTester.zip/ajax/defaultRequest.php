<p>Default request. Request method was GET. Ajax is working. This request was issued by
    the <?php echo trim($_GET['issuingApp']); ?> app and was handled
    by <?php echo trim($_GET['handlerName']); ?>.php</p>
<?php
var_dump('GET', $_GET);
var_dump('POST', $_POST);
