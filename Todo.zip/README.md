The Todo app scans the Darling Cms for any todo messages and displays them in an admin panel.
