The Error Viewer provides a user interface for viewing any errors that have been logged to the default PHP error log. The Error Viewer can also be configured to display additional error logs.
