<?php
$todos = array(
    'Allow select range from UI | Will apply to following views: Punches, Time Worked, Earnings, Invoice',
    'Allow select specific Time Cards from UI | This option will need to also allow to limit choices by range. | Will apply to following views: Punches, Time Worked, Earnings, Invoice',
    'Create Invoice from Time Cards | Create Invoice class',
    'Export Invoice as (json, csv, pdf, html, etc...)',
    'Refactor the Today view so it is responsible for displaying information about any selected time card, defaulting to "today" by default. This new view should be called "View Time Card".'
);
$tasks = count($todos);
?>
<div style="overflow: auto;width:98%;height:420px;font-size:1.5em;position: fixed; top: 470px; left: 10px;background: #040e21;padding: 20px;border-radius: 20px;border:3px solid #ffffff;"
     draggable="true" class="makeDraggable">
    <h1>Todo:</h1>
    <p>You have <?php echo strval($tasks); ?> things to do.</p>
    <ul>
        <li><h3>Earnings App</h3></li>
        <?php
        foreach ($todos as $todo) {
            echo "<li>{$todo}</li>";
        }
        ?>
    </ul>
</div>
