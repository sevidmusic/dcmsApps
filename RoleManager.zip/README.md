Create, read, update, and delete Roles.
