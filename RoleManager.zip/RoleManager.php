<?php

use \DarlingCms\classes\staticClasses\core\CoreValues;

$roleUi = new \Apps\RoleManager\classes\RoleManagerUi();
echo $roleUi->getUserInterface();
