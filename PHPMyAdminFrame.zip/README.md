Provides an iframe to PHPMyAdmin. 

WARNING: This app is intended to be used in local environments using a MAMP server setup. 

DO NOT USE THIS IN PRODUCTION!!!!
