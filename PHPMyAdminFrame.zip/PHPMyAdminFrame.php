<div id="PHPMyAdminFrame" class="dcms-admin-panel dcms-admin-panel-pos2 dcms-make-draggable">
    <div id="PHPMyAdminFrameHandle" draggable="true" class="dcms-drag-handle">Click here to move...</div>
    <div id="PHPMyAdminFrameCurrentView">
        <iframe style=" width: 100%; height: 390px;"
                src="http://localhost:8888/phpMyAdmin/sql.php?db=PDOPlaygroundDev1"></iframe>
    </div>
</div>
