Converts tokens to cash. (1 token = $0.05)
