<?php

use Apps\TokenConverter\UI;

$userInterface = new UI();
echo $userInterface->getUserInterface();
